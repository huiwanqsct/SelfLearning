package util;

public class Bug
{
  public Bug()
  {
    throw new java.lang.Error("Compiler bug");
  }
}
