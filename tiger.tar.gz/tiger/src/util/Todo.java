package util;

import slp.Slp.ExpList;
import slp.Slp.Stm;

public class Todo
{
	public Todo()
	{
		System.out.println("TODO: please add your code here:\n");
		throw new java.lang.Error (); 
	}
}
